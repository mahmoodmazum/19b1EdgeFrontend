import React from "react";

function About() {
  return <div>This is about page</div>;
}

export default About;
